# EN3150 Assignment 03 - Xception code submission

The report PDF is submitted separately. Extract this entire ZIP before use.
Open the six numbered top-level notebooks in order, or run each independently
with a fresh Python kernel. Each contains the original commented Python source
plus a workflow. Source cells write the corresponding files in raw_code/.
The additional colab_run.ipynb is the original optional Drive-backed runner;
it clones the public repository and is not needed for the six task notebooks.

Python 3.10+ is required. For local Jupyter, install with:
    python -m pip install -r raw_code/requirements.txt jupyterlab
    python -m jupyterlab
On Google Colab, upload this ZIP, extract it into /content, open a notebook,
and enable INSTALL_DEPENDENCIES in its setup cell. A GPU is recommended for
full experiments. Notebook 01 prepares EuroSAT when PREPARE_DATA is enabled.

Default workflows inspect recorded results, construct the actual custom models,
run a tiny offline smoke test, and regenerate report tables/figures. Full
training is opt-in and writes rerun_* directories rather than overwriting the
recorded benchmarks. The smoke test uses synthetic data and a small stand-in
network, and does not reproduce the report's accuracies.

raw_code/ includes the Python package, CLI scripts, tests, YAML configs,
recorded JSON/figures, split manifest, normalization statistics and LaTeX
report sources. Notebooks 04 (MobileNetV2) and 05 (EfficientNet-B0) each include
the shared pretrained-model and diagnostic source, inspect only their own
recorded runs, and offer opt-in training and diagnostic reruns.

No dataset images, pretrained downloads, checkpoints, environment, Git history,
AGENTS.md or CLAUDE.md are included. EuroSAT and ImageNet weights download only
when the relevant full preparation/training workflow is enabled. Recorded
results are preserved as evidence; notebook outputs are deliberately cleared.

To run the original CLI directly:
    cd raw_code
    python scripts/run_experiment.py --config configs/model_b.yaml --smoke
    python -m pytest

Project: https://github.com/dpiyumal2319/pattern-recognition-cnn-edge
EuroSAT dataset: https://github.com/phelber/EuroSAT
